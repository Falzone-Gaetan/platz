<div class="container object">
    <div id="main-container-image">
      

     
        @yield('content')

      
    </div>
