<div id="wrapper-oldnew">
    <div class="oldnew">
      <div class="wrapper-oldnew-prev">
        <div id="oldnew-prev"></div>
      </div>
    </div>
  </div>