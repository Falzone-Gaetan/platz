<div id="wrapper-copyright">
    <div class="copyright">
      <div class="copy-text object">
        Copyright © 2016. Template by
        <a style="color: #d0d1d4" href="https://dcrazed.com/">Dcrazed</a>
      </div>

      <div class="wrapper-navbouton">
        <div class="google object">g</div>
        <div class="facebook object">f</div>
        <div class="linkin object">i</div>
        <div class="dribbble object">d</div>
      </div>
    </div>
  </div>